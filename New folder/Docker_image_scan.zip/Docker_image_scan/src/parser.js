import * as XLSX from "xlsx";

// ─── TEXT / TXT PARSER ────────────────────────────────────────────────────────
function parseBlackDuckLine(line) {
  line = line.trim();
  if (!line) return null;

  const layerMatch = line.match(/Layer\s+(\d+)/i);
  const layer = layerMatch ? parseInt(layerMatch[1]) : 0;
  const pctMatch = line.match(/(\d+)%/);
  const matchPercent = pctMatch ? parseInt(pctMatch[1]) : 100;
  const riskMatch = line.match(/\b(Critical|High|Medium|Low)\b/i);
  const risk = riskMatch
    ? riskMatch[1][0].toUpperCase() + riskMatch[1].slice(1).toLowerCase()
    : line.match(/Ignored/i) ? "Ignored" : "None";
  const linkMatch = line.match(/(Dynamically Linked|Statically Linked|Not Linked)/i);
  const linkType = linkMatch ? linkMatch[1] : "Unknown";
  const detMatch = line.match(/\b(Binary|Source|Signature|Manual)\b/i);
  const detectionType = detMatch ? detMatch[1] : "Binary";
  const depMatch = line.match(/(Direct Dependency|Transitive|Development)/i);
  const depType = depMatch ? depMatch[1] : "Direct Dependency";
  const licenseMatch = line.match(
    /(MIT|ISC|Apache-[\d.]+(?:-or-later)?|GPL-[\d.]+(?:-or-later|-only)?|LGPL-[\d.]+(?:-or-later|-only)?|BSD-[\d]+-Clause|MPL-[\d.]+|CC0-[\d.]+|Unlicense|CDDL-[\d.]+|EPL-[\d.]+)/i
  );
  const license = licenseMatch ? licenseMatch[1] : "Unknown";

  const beforeLayer = line.split(/Layer\s+\d+/i)[0].trim();
  const tokens = beforeLayer.split(/\s+/);
  let version = "?", nameParts = tokens;
  for (let i = tokens.length - 1; i >= 0; i--) {
    if (/^\d[\d.]+/.test(tokens[i])) {
      version = tokens[i];
      nameParts = tokens.slice(0, i);
      break;
    }
  }
  const name = nameParts.join(" ").replace(/\s*\(.*?\)/, "").trim() || beforeLayer;
  return { name, version, layer, depType, detectionType, matchPercent, linkType, license, risk, raw: line };
}

export function parseText(text) {
  return text.split("\n").map(parseBlackDuckLine).filter(Boolean);
}

// ─── EXCEL / CSV PARSER ───────────────────────────────────────────────────────
// Handles .xlsx, .xls, .csv files.
// Tries to map columns by header name, then falls back to positional mapping.
export function parseExcelFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });

        if (!rows.length) { resolve([]); return; }

        // Try to find header row (first row that looks like headers)
        let headerIdx = 0;
        const firstRow = rows[0].map(c => String(c).toLowerCase().trim());
        const hasHeaders = firstRow.some(h =>
          ["name", "component", "version", "layer", "risk", "license", "type"].some(k => h.includes(k))
        );

        const headers = hasHeaders ? firstRow : null;
        const dataRows = hasHeaders ? rows.slice(1) : rows;

        const colIdx = (names) => {
          if (!headers) return -1;
          for (const n of names) {
            const i = headers.findIndex(h => h.includes(n));
            if (i !== -1) return i;
          }
          return -1;
        };

        const nameCol    = colIdx(["component", "name", "pkg", "package"]);
        const verCol     = colIdx(["version", "ver"]);
        const layerCol   = colIdx(["layer"]);
        const riskCol    = colIdx(["risk", "severity", "vuln"]);
        const licCol     = colIdx(["license", "lic"]);
        const depCol     = colIdx(["dep", "dependency type", "type"]);
        const linkCol    = colIdx(["link", "linked"]);
        const matchCol   = colIdx(["match", "confidence", "%"]);
        const detCol     = colIdx(["detect", "method"]);

        const get = (row, idx, fallback = "") =>
          idx >= 0 && row[idx] != null ? String(row[idx]).trim() : fallback;

        const components = [];
        dataRows.forEach((row, ri) => {
          if (!row || row.every(c => !c)) return;

          // Positional fallback: col0=name, col1=version, col2=layer...
          const rawName    = nameCol  >= 0 ? get(row, nameCol)  : get(row, 0);
          const rawVersion = verCol   >= 0 ? get(row, verCol)   : get(row, 1);
          const rawLayer   = layerCol >= 0 ? get(row, layerCol) : get(row, 2);
          const rawRisk    = riskCol  >= 0 ? get(row, riskCol)  : get(row, 5, "None");
          const rawLic     = licCol   >= 0 ? get(row, licCol)   : get(row, 6, "Unknown");
          const rawDep     = depCol   >= 0 ? get(row, depCol)   : get(row, 3, "Direct Dependency");
          const rawDet     = detCol   >= 0 ? get(row, detCol)   : get(row, 4, "Binary");
          const rawLink    = linkCol  >= 0 ? get(row, linkCol)  : "Dynamically Linked";
          const rawMatch   = matchCol >= 0 ? get(row, matchCol) : "100";

          if (!rawName) return;

          const layerNum = parseInt(rawLayer) || 0;
          const pctNum   = parseInt(String(rawMatch).replace(/[^0-9]/g, "")) || 100;
          const riskNorm = ["Critical","High","Medium","Low","Ignored","None"].find(
            r => rawRisk.toLowerCase().includes(r.toLowerCase())
          ) || "None";

          const raw = `${rawName} ${rawVersion} Layer ${layerNum} ${rawDep} ${rawDet} ${pctNum}% ${rawLink} ${rawLic} ${riskNorm}`;
          components.push({
            name: rawName,
            version: rawVersion || "?",
            layer: layerNum,
            depType: rawDep || "Direct Dependency",
            detectionType: rawDet || "Binary",
            matchPercent: pctNum,
            linkType: rawLink || "Dynamically Linked",
            license: rawLic || "Unknown",
            risk: riskNorm,
            raw,
          });
        });

        resolve(components);
      } catch (err) {
        reject(new Error("Excel parse failed: " + err.message));
      }
    };
    reader.onerror = () => reject(new Error("File read error"));
    reader.readAsArrayBuffer(file);
  });
}

// ─── CSV TEXT PARSER ──────────────────────────────────────────────────────────
export function parseCsvText(text) {
  const lines = text.split("\n").filter(l => l.trim());
  if (!lines.length) return [];

  // Detect if first line is a header
  const first = lines[0].toLowerCase();
  const hasHeader = ["name","component","version","layer","risk"].some(k => first.includes(k));
  const dataLines = hasHeader ? lines.slice(1) : lines;

  return dataLines.map(line => {
    const cols = line.split(",").map(c => c.replace(/^"|"$/g, "").trim());
    if (!cols[0]) return null;
    return {
      name: cols[0] || "?",
      version: cols[1] || "?",
      layer: parseInt(cols[2]) || 0,
      depType: cols[3] || "Direct Dependency",
      detectionType: cols[4] || "Binary",
      matchPercent: parseInt(cols[5]) || 100,
      linkType: cols[6] || "Dynamically Linked",
      license: cols[7] || "Unknown",
      risk: cols[8] || "None",
      raw: line,
    };
  }).filter(Boolean);
}
