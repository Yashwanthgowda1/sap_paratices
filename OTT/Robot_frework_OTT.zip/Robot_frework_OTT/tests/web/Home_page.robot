*** Settings ***
Resource   	../library/common_web_andriod.py
Resource	../../library/common_web.robot


*** Test Cases ***
signin to orangeHRM
    [Tags]  56754   smoke
    Open Web Browser And Go To URL
    [Teardown]
    


    
    