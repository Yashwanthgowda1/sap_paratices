from selenium import webdriver
import time
i=0
while i>=0:
    drivre=webdriver.Chrome()
    drivre.get("https://nosleep.page/")
    time.sleep(500)
    drivre.quit()
    i=+1