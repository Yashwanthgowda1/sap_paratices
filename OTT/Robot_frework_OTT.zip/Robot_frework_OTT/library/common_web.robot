*** Settings ***

Library    ../library/common_web_andriod.py
Library  	../library/sign_in.py


*** Variables ***
${BROWSER}    chrome

${URL}        https://opensource-demo.orangehrmlive.com/web/index.php/auth/login


*** Keywords ***

Open Web Browser And Go To URL
    Initialize Driver    device_type=web    browser=chrome
    go_to_url    ${URL}
	perform_login
