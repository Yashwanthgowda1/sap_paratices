import json, os, time
from selenium.webdriver.common.by import By
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from initialize_browser import InitializeBrowser
from Setuputility import SetupUtility
from robot.api.deco import keyword
from robot.api import logger

driver = None

# Load configuration and locators
config = SetupUtility.load_config()
sign_in_dict = SetupUtility.load_config("resource/page_object/sigin.json")


def get_login_credentials():
    username = config['login_credentials']['username']
    password = config['login_credentials']['password']
    return username, password


@keyword
def initialize_driver(device_type="web", browser="chrome"):
    """Initialize driver once for web or Android."""
    global driver
    device_type = device_type.strip('"').strip("'")
    if device_type.lower() in ["android", "real_device", "emulator"]:
        driver = SetupUtility().connect_device(device_type=device_type)
    elif device_type.lower() == "web":
        driver = InitializeBrowser().initialize_browser(browser_name=browser)
    else:
        raise ValueError(f"Unsupported device type: {device_type}")
    return driver


@keyword
def go_to_url(url):
    """Navigate to the given URL using Selenium driver."""
    global driver
    if driver is None:
        raise Exception("Driver not initialized. Call 'Initialize Driver' first.")
    driver.get(url)


@keyword
def take_screenshot_on_error(message):
    """Take screenshot and log in Robot Framework report."""
    global driver
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    screenshot_name = f"screenshot_{timestamp}.png"
    screenshot_path = os.path.join(os.getcwd(), screenshot_name)

    if driver:
        driver.save_screenshot(screenshot_path)
        logger.error(message)
        logger.info(
            f'<a href="{screenshot_name}"><img src="{screenshot_name}" width="800px"></a>',
            html=True
        )
    else:
        logger.error("Driver not initialized, cannot take screenshot.")


@keyword
def find_element(device_type, locator_dict, locator_key, timeout=10):
    """Find an element and handle failures with screenshot logging."""
    global driver
    try:
        if driver is None:
            initialize_driver(device_type)

        if locator_key not in locator_dict:
            raise KeyError(f"Locator '{locator_key}' not found in {locator_dict}")

        locator_all_keypairs = locator_dict[locator_key]

        by_type_andriod = {
            "id": AppiumBy.ID,
            "xpath": AppiumBy.XPATH,
            "accessibility_id": AppiumBy.ACCESSIBILITY_ID,
            "class_name": AppiumBy.CLASS_NAME,
            "android_ui_automator": AppiumBy.ANDROID_UIAUTOMATOR
        }
        by_type_web = {
            "id": By.ID,
            "xpath": By.XPATH,
            "xpath1": By.XPATH,
            "text": By.LINK_TEXT,
            "css": By.CSS_SELECTOR
        }

        by_type_choice = by_type_andriod if device_type.lower() in ["android", "real_device", 'emulator'] else by_type_web

        for loc_key, loc_value in locator_all_keypairs.items():
            value_of_choice = by_type_choice.get(loc_key.lower())
            if value_of_choice:
                try:
                    return driver.find_element(value_of_choice, loc_value)
                except Exception:
                    continue
    except Exception as e:
        take_screenshot_on_error(f"Error finding element '{locator_key}': {e}")
        raise e


@keyword
def perform_login(device_type="web"):
    """Perform login using credentials from config."""
    global driver
    username, password = get_login_credentials()

    element = find_element(device_type, sign_in_dict, "sing_in_page")
    if element:
        find_element(device_type, sign_in_dict, "username_text_field").send_keys(username)
        find_element(device_type, sign_in_dict, "password_text_field").send_keys(password)
        find_element(device_type, sign_in_dict, "login_button").click()

        try:
            WebDriverWait(driver, 10).until(EC.title_contains("Dashboard"))
        except TimeoutException:
            take_screenshot_on_error("Login not done successfully")
            raise Exception("Login not done successfully")


@keyword
def quit_driver():
    """Quit the driver if it's running."""
    global driver
    if driver:
        try:
            driver.quit()
            print("[INFO] Driver quit successfully.")
        except Exception as e:
            print(f"[ERROR] Error while quitting driver: {e}")
        finally:
            driver = None
